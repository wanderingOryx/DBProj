/*1. Multiple table query.*/
SELECT 
/*2. Corrolated nested query.*/
/*3. Uncorrolated nested query.*/
/*4. Query using union, intersect and minus.*/
/*5. Query using exist, not exist, in, not in, all.*/
/*6. Query using aggregate functions, group by, sort by and having.*/