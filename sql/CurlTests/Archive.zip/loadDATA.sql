
load data
infile example.csv
into table Customer
fields terminated by ','
(cID, numPeople, status, name, email, phone)

load data
infile example.csv
into table Customer
fields terminated by ','
(cID, numPeople, status, name, email, phone)
